# SDK API Doc

<Toc />

[环信 Android SDK 3.X API Doc](https://sdkdocs.easemob.com/apidoc/android/chat3.0/annotated.html)
